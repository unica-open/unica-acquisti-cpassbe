Versione di prodotto    1.5.0

Versione Componenti
cpassrepeng 1.1.0
cpassManual 1.5.0 
cpassscript 1.2.0
cpassbatch 1.2.0    
cpassDB 1.5.0
cpassbe 1.5.0
cpassfe 1.5.0
cpassreptpl 1.5.0

Versione di prodotto    1.6.0

Versione Componenti
cpassrepeng 1.2.0
cpassManual 1.6.0 
cpassscript 1.2.0
cpassbatch 1.2.0    
cpassDB 1.6.0
cpassbe 1.6.0
cpassfe 1.6.0
cpassreptpl 1.6.0

Versione di prodotto    1.7.0 

Versione Componenti
cpassrepeng 1.2.0				
cpassreptpl 1.6.0               
cpassManual 1.6.0               
cpassscript 1.3.0                
cpassbatch 1.4.0                 
cpassDB 1.7.0                    
cpassbe 1.7.0                    
cpassfe 1.7.0                    


Versione di prodotto    1.8.0 
Versione Componenti
cpassrepeng 1.2.0				
cpassreptpl 1.6.0               
cpassscript 1.3.0                
cpassbatch 1.4.0                 
cpassManual 1.7.0           new    
cpassDB 1.8.0               new     
cpassbe 1.8.0               new     
cpassfe 1.8.0               new  


Versione di prodotto    1.9.0 
Versione Componenti
cpassrepeng 1.2.0			old	   
cpassreptpl 1.7.0           new    
cpassscript 1.3.0           old    
cpassbatch 1.4.0            old    
cpassManual 1.8.0           new    
cpassDB 1.9.0               new    
cpassbe 1.9.0               new    
cpassfe 1.9.0               new    

Versione di prodotto    1.10.0 (aggiornati pure i pom)
Versione Componenti
cpassrepeng 1.2.0			 old	  
cpassreptpl 1.7.0            old    
cpassscript 1.3.0            old     
cpassbatch 1.4.0             old    
cpassManual 1.9.0            new    
cpassDB 1.10.0               new 
cpassbe 1.10.0               new    
cpassfe 1.10.0               new    

Versione di prodotto    	 1.11.0 
Versione Componenti
cpassrepeng 1.2.0			 old	  
cpassscript 1.4.0            new    
cpassbatch 1.5.0             new   
cpassManual 1.10.0           new    
cpassreptpl 1.8.0            new    
cpassDB 1.11.0               new 
cpassbe 1.11.0               new    
cpassfe 1.11.0               new    

Versione di prodotto    	 1.12.0 
Versione Componenti
cpassrepeng 1.2.0			 old	  
cpassscript 1.4.0            old    
cpassbatch 1.5.0             old   
cpassManual 1.10.0           old    
cpassreptpl 1.8.0            old    
cpassDB 1.12.0               new 
cpassbe 1.12.0               new    
cpassfe 1.12.0               new    

Versione di prodotto    	 1.13.0 
Versione Componenti
cpassrepeng 1.2.0			 old	  
cpassscript 1.4.0            old    
cpassbatch 1.5.0             old   
cpassManual 1.10.0           old    
cpassreptpl 1.9.0            new    
cpassDB 1.13.0               new 
cpassbe 1.13.0               new    
cpassfe 1.13.0               new 

Versione di prodotto    	 1.14.0 
Versione Componenti
cpassrepeng 1.2.0			 old	  
cpassscript 1.4.0            old    
cpassbatch 1.5.0             old   
cpassManual 1.11.0           new    
cpassreptpl 1.10.0           new    
cpassDB 1.14.0               new 
cpassbe 1.14.0               new    
cpassfe 1.14.0               new 

Versione di prodotto    	 1.15.0 
Versione Componenti
cpassrepeng 1.2.0			 old	  
cpassscript 1.4.0            old    
cpassbatch 1.5.0             old   
cpassManual 1.11.0           old    
cpassreptpl 1.11.0           new    
cpassDB 1.15.0               new 
cpassbe 1.15.0               new    
cpassfe 1.15.0               new 

Versione di prodotto    	 1.16.0 
Versione Componenti
cpassrepeng 1.2.0			 old	  
cpassscript 1.4.0            old    
cpassbatch 1.5.0             old   
cpassManual 1.11.0           old    
cpassreptpl 1.12.0           new    
cpassDB 1.16.0               new 
cpassbe 1.16.0               new    
cpassfe 1.16.0               new 

Versione di prodotto    	 1.17.0 
Versione Componenti
cpassrepeng 1.2.0			 old	  
cpassscript 1.4.0            old    
cpassbatch 1.5.0             old   
cpassManual 1.11.0           old    
cpassreptpl 1.12.0           old    
cpassDB 1.17.0               new 
cpassbe 1.17.0               new    
cpassfe 1.17.0               new 


Versione di prodotto    	 1.18.0 
Versione Componenti
cpassrepeng 1.2.0			 old	  
cpassscript 1.4.0            old    
cpassbatch 1.5.0             old   
cpassManual 1.11.0           old    
cpassreptpl 1.13.0           new    
cpassDB 1.18.0               new 
cpassbe 1.18.0               new    
cpassfe 1.18.0               new 



Versione di prodotto    	 1.19.0 
Versione Componenti
cpassrepeng 1.2.0			 old	  
cpassscript 1.4.0            old    
cpassbatch 1.5.0             old   
cpassManual 1.12.0           new    
cpassreptpl 1.14.0           new    
cpassDB 1.19.0               new 
cpassbe 1.19.0               new    
cpassfe 1.19.0               new 



Versione di prodotto    	  1.20.0 
Versione Componenti
cpassrepeng 1.2.0			     old	  
cpassscript 1.5.0                new    
cpassbatch  1.6.0                new   
cpassManual 1.13.0               new    
cpassreptpl 1.15.0               new    
cpassDB     1.20.0               new 
cpassbe     1.20.0               new    
cpassfe     1.20.0               new 


Versione di prodotto    	  1.21.0 
Versione Componenti
cpassrepeng 1.2.0			     old	  
cpassscript 1.5.0                old    
cpassbatch  1.6.0                old   
cpassManual 1.13.0               old    
cpassreptpl 1.16.0               new    
cpassDB     1.21.0               new 
cpassbe     1.21.0               new    
cpassfe     1.21.0               new 

Versione di prodotto    	  1.22.0 
Versione Componenti
cpassrepeng 1.2.0			     old
cpassreptpl 1.16.0               old    
cpassscript 1.6.0                new    
cpassManual 1.14.0               new     
cpassbatch  1.7.0                new   
cpassDB     1.22.0               new   
cpassbe     1.22.0               new    
cpassfe     1.22.0               new  

Versione di prodotto    	  1.23.0 
Versione Componenti
cpassrepeng 1.2.0			     old
cpassreptpl 1.17.0               new    
cpassscript 1.6.0                old    
cpassManual 1.15.0               new     
cpassbatch  1.7.0                old   
cpassDB     1.23.0               new   
cpassbe     1.23.0               new    
cpassfe     1.23.0               new   

Versione di prodotto    	  1.24.0 
Versione Componenti
cpassrepeng 1.2.0			     old
cpassreptpl 1.18.0               new    
cpassscript 1.6.0                old    
cpassManual 1.15.0               old     
cpassbatch  1.7.0                old   
cpassDB     1.24.0               new   
cpassbe     1.24.0               new    
cpassfe     1.24.0               new       

Versione di prodotto    	  1.25.0 
Versione Componenti
cpassrepeng 1.3.0			     new
cpassreptpl 1.18.0               old    
cpassscript 1.6.0                old    
cpassManual 1.15.0               old     
cpassbatch  1.8.0                new   
cpassDB     1.25.0               new   
cpassbe     1.25.0               new    
cpassfe     1.25.0               new       
